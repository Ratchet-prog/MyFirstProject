package com.example.PentOX;
import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.media.AudioAttributes;
import android.media.AudioManager;
import android.media.SoundPool;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.MobileAds;
import android.app.AlertDialog;
import android.os.Build;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.text.style.StyleSpan;
import android.widget.Toast;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.google.android.gms.ads.InterstitialAd;

import static android.media.AudioManager.*;

public class HomeActivity extends AppCompatActivity implements View.OnClickListener{
    private Button[][] buttons = new Button[5][5];
    private boolean player1Turn = true;
    private int roundCount;
    private int player1Points;
    private int player2Points;
    Dialog myDialog;
    Button positiveDialog;
    AlertDialog.Builder dialogBuilder;
    AlertDialog alertDialog;
    private SoundPool soundPool;
    private int sound;
    private TextView textViewPlayer1;
    private TextView textViewPlayer2;
    private TextView textview;
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        positiveDialog = findViewById(R.id.button);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            AudioAttributes audioAttributes = new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build();

            soundPool = new SoundPool.Builder()
                    .setMaxStreams(6)
                    .setAudioAttributes(audioAttributes)
                    .build();
        } else {
            soundPool = new SoundPool(6, STREAM_MUSIC, 0);
        }

        sound = soundPool.load(this, R.raw.beep, 1);
        MobileAds.initialize(this, "ca-app-pub-2831459295371249~8076612323");
            final InterstitialAd interstitialAd = new InterstitialAd(this);
            interstitialAd.setAdUnitId("ca-app-pub-3940256099942544/1033173712");
            interstitialAd.loadAd(new AdRequest.Builder().build());
            textViewPlayer1 = findViewById(R.id.text_view_p1);
            textViewPlayer2 = findViewById(R.id.text_view_p2);
        textview = findViewById(R.id.textView);
            for (int i = 0; i < 5; i++) {
                for (int j = 0; j < 5; j++) {
                    String buttonID = "button_" + i + j;
                    int resID = getResources().getIdentifier(buttonID, "id", getPackageName());
                    buttons[i][j] = findViewById(resID);
                    buttons[i][j].setOnClickListener(this);
                }
            }
            myDialog = new Dialog(this);
            Button buttonReset = findViewById(R.id.button_reset);
            Button Play_Again = findViewById(R.id.PlayAgain);
            buttonReset.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    interstitialAd.show();
                    resetGame();
                }
            });
            Button Rules = findViewById(R.id.Rules);
            Rules.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    openDialog();
                }
            });
            Play_Again.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    AudioManager myAudioManager = (AudioManager)getSystemService(Context.AUDIO_SERVICE);
                    myAudioManager.setRingerMode(AudioManager.RINGER_MODE_SILENT);
                }
            });
        }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        soundPool.release();
        soundPool = null;
    }
    @Override
    public void onClick(View v) {
        soundPool.play(sound, 1, 1, 0, 0, 1);
        String st="X";
        String st1="O";
        SpannableString ss = new SpannableString(st);
        SpannableString so = new SpannableString(st1);
        ForegroundColorSpan fcsRED = new ForegroundColorSpan(Color.RED);
        ForegroundColorSpan fcsBLUE = new ForegroundColorSpan(Color.BLUE);
        ss.setSpan(fcsRED,0,1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        so.setSpan(fcsBLUE,0,1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        StyleSpan boldSpan= new StyleSpan(Typeface.BOLD);
        ss.setSpan(boldSpan,0,1,Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        so.setSpan(boldSpan,0,1,Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        if (!((Button) v).getText().toString().equals("")) {
            return;
        }

        if (player1Turn) {

            ((Button) v).setText(ss);
        } else {
            ((Button) v).setText(so);
        }


        roundCount++;

        if (checkForWin()) {
            if (player1Turn) {
                player1Wins();
            } else {
                player2Wins();
            }
        } else if (roundCount == 25) {
            draw();
        } else {
            player1Turn = !player1Turn;
        }
    }
    private void showAlertDialog(int layout,int n){
        dialogBuilder = new AlertDialog.Builder(HomeActivity.this);
        View layoutView = getLayoutInflater().inflate(layout, null);
        Button dialogButton = layoutView.findViewById(R.id.button);
        TextView dialogText=layoutView.findViewById(R.id.textView);
        dialogBuilder.setView(layoutView);
        alertDialog = dialogBuilder.create();
        alertDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        alertDialog.show();
       if(n==1)
       {
           dialogText.setText("Player 1 Won!");
       }
       else if(n==2)
       {
           dialogText.setText("Player 2 Won");
       }
       else
       {
           dialogText.setText("Draw");
       }
        dialogButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                resetBoard();
                alertDialog.dismiss();
            }
        });
    }
    public void openDialog() {
        ExampleDialog exampleDialog = new ExampleDialog();
        exampleDialog.show(getSupportFragmentManager(), "example dialog");
    }

    private boolean checkForWin() {
        String[][] field = new String[5][5];

        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 5; j++) {
                field[i][j] = buttons[i][j].getText().toString();
            }
        }

        for (int i = 0; i < 5; i++) {
            if ((field[i][0].equals(field[i][1])
                    && field[i][0].equals(field[i][2])&& field[i][0].equals(field[i][3])
                    && !field[i][0].equals("") )|| (field[i][1].equals(field[i][2])
                    && field[i][1].equals(field[i][3]) && field[i][1].equals(field[i][4])
                    && !field[i][1].equals(""))) {
                return true;
            }
        }

        for (int i = 0; i < 5; i++) {
            if ((field[0][i].equals(field[1][i])
                    && field[0][i].equals(field[2][i]) && field[0][i].equals(field[3][i])
                    && !field[0][i].equals(""))||(field[1][i].equals(field[2][i])
                    && field[1][i].equals(field[3][i]) && field[1][i].equals(field[4][i])
                    && !field[1][i].equals(""))) {
                return true;
            }
        }

        if ((field[0][0].equals(field[1][1])
                && field[0][0].equals(field[2][2])&& field[0][0].equals(field[3][3])
                && !field[0][0].equals(""))||(field[1][1].equals(field[2][2])
                && field[2][2].equals(field[3][3]) && field[1][1].equals(field[4][4])
                && !field[1][1].equals(""))) {
            return true;
        }
        if (field[0][1].equals(field[1][2])
                && field[0][1].equals(field[2][3])&& field[0][1].equals(field[3][4])
                && !field[0][1].equals("")) {
            return true;
        }
        if (field[1][0].equals(field[2][1])
                && field[1][0].equals(field[3][2])&& field[1][0].equals(field[4][3])
                && !field[1][0].equals("")) {
            return true;
        }

        if ((field[0][4].equals(field[1][3])
                && field[0][4].equals(field[2][2])&& field[0][4].equals(field[3][1])
                && !field[0][4].equals(""))||(field[4][0].equals(field[3][1])
                && field[4][0].equals(field[2][2])&& field[4][0].equals(field[1][3])
                && !field[4][0].equals(""))) {
            return true;
        }
        if (field[0][3].equals(field[1][2])
                && field[0][3].equals(field[2][1])&& field[0][3].equals(field[3][0])
                && !field[0][3].equals("")) {
            return true;
        }
        if (field[1][4].equals(field[2][3])
                && field[1][4].equals(field[3][2]) && field[1][4].equals(field[4][1])
                && !field[1][4].equals("")) {
            return true;
        }

        return false;
    }
    private void player1Wins() {
        player1Points++;
        updatePointsText();
        showAlertDialog(R.layout.activity_play_again ,1);
    }

    private void player2Wins() {

        player2Points++;
        updatePointsText();
        showAlertDialog(R.layout.activity_play_again ,2);
    }

    private void draw() {
        showAlertDialog(R.layout.activity_play_again ,0);
        resetBoard();

    }

    private void updatePointsText() {
        textViewPlayer1.setText("Player 1: " + player1Points);
        textViewPlayer2.setText("Player 2: " + player2Points);
    }

    private void resetBoard() {
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 5; j++) {
                buttons[i][j].setText("");
            }
        }

        roundCount = 0;
        player1Turn = true;
    }
    private void PlayAgain() {
        resetBoard();
    }
    private void resetGame() {
        player1Points = 0;
        player2Points = 0;
        updatePointsText();
        resetBoard();
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);

        outState.putInt("roundCount", roundCount);
        outState.putInt("player1Points", player1Points);
        outState.putInt("player2Points", player2Points);
        outState.putBoolean("player1Turn", player1Turn);
    }

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);

        roundCount = savedInstanceState.getInt("roundCount");
        player1Points = savedInstanceState.getInt("player1Points");
        player2Points = savedInstanceState.getInt("player2Points");
        player1Turn = savedInstanceState.getBoolean("player1Turn");
    }




}

