package com.example.PentOX;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;

public class Menu extends AppCompatActivity {
private Button b1,b2,b3;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);
        b1=findViewById(R.id.sp);
        b2=findViewById(R.id.mp1);
        b3=findViewById(R.id.mp2);
        b1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick (View v){
                    Intent homeIntent = new Intent(Menu.this, HomeActivity.class);
                    startActivity(homeIntent);
                }
        });
        b2.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick (View v){
                    Intent homeIntent2 = new Intent(Menu.this, HomeActivity2.class);
                    startActivity(homeIntent2);
                }
        });
        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick (View v){
                Intent homeIntent2 = new Intent(Menu.this, Multi.class);
                startActivity(homeIntent2);
            }
        });


    }
}
