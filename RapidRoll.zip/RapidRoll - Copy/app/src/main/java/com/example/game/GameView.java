package com.example.game;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.media.MediaPlayer;
import android.os.CountDownTimer;
import android.os.Handler;
import android.util.Log;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

class GameView extends SurfaceView implements SurfaceHolder.Callback {
    private GameThread gameThread=null;
    private Bitmap bmp,player,star1,star2,loading1,loading2,loading3;
    private  Canvas can;
    private long startTime,startTime1=10000,startTime2=1000,mTimeLeftInMillis=5000;
    Paint paint = new Paint();
    String str="0";
    public int in=0,sp=0,k=0;
    private int y=100,x=100,y1=0,sc=0;
    private int xSpeed = 15;
    private int ySpeed = 10;
    private  int j=1,flag=0,i=0;
    Sprite spr=null,a;
    Button btn;
    TextView t;
    Boolean isPlaying =true,isInvincible=false;
    private  MediaPlayer nSound;
    private static List<Sprite> sprites = new ArrayList<Sprite>();
    private static List<Sprite> needles = new ArrayList<Sprite>();
    CountDownTimer mCountDownTimer,mCountDownTimer1;
    private SurfaceHolder surfaceHolder = null;
    public GameView(Context context) {
        super(context);
        // Get SurfaceHolder object.
        surfaceHolder = this.getHolder();
        // Add current object as the callback listener.
        surfaceHolder.addCallback(this);
        nSound = MediaPlayer.create(context, R.raw.pop);
        bmp = BitmapFactory.decodeResource(getResources(),R.drawable.mountain);
        player = BitmapFactory.decodeResource(getResources(),R.drawable.ball);
        star1 = BitmapFactory.decodeResource(getResources(),R.drawable.star1);
        star2 = BitmapFactory.decodeResource(getResources(),R.drawable.star2);
        loading1 = BitmapFactory.decodeResource(getResources(),R.drawable.loading1);

        loading2 = BitmapFactory.decodeResource(getResources(),R.drawable.loading2);
        loading3= BitmapFactory.decodeResource(getResources(),R.drawable.loading3);
        startTimer();
    }
    public void pause() {

isPlaying=false;


    }

    public void bars()
    {
        sprites.add(createSprite(R.drawable.mummy));
        if(sp%30==0 && sp!=0)
        {
            sprites.get(sprites.size()-1).sendStar(star1);
            sprites.get(sprites.size()-1).sendp(1);
        }

        sp++;
        if(sp>in+10)
        {
            k=0;
        }



    }
    int getx()
    {
        return x;
    }
    int gety()
    {
        return y;
    }
    Bitmap bmp()
    {
        return player;
    }
    public void needles() {


        needles.add(createSprite(R.drawable.needle));
    }
    private Sprite createSprite(int resource)
    {
        Bitmap bmp1 = BitmapFactory.decodeResource(getResources(), resource);
        a = new Sprite(this,bmp1,y1/10);
        y1++;
        return a;
    }
   public void startTimer() {
if(isPlaying) {
    startTime = 4000;
    mCountDownTimer = new CountDownTimer(startTime, 1000) {
        @Override
        public void onTick(long millisUntilFinished) {
            startTime = millisUntilFinished;
            if (startTime < 4000)
                bars();
            else

                needles();

        }

        @Override
        public void onFinish() {
            i = 0;

            sprites.remove(0);
            if (flag != 1)
                startTimer();
        }
    }.start();
}
    }
    @Override
    public void surfaceCreated(SurfaceHolder holder) {
        gameThread = new GameThread(this,holder);
        gameThread.setRunning(true);
        gameThread.start();
    }

    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {

    }

    @Override
    public void surfaceDestroyed(SurfaceHolder holder) {

        boolean retry = true;
        gameThread.setRunning(false);
        while (retry) {
            try {
                gameThread.join();
                retry = false;
            } catch (InterruptedException e) {

            }
        }
    }
    protected void onDraw(Canvas canvas)
    {


        can=canvas;
         if (canvas != null) {
             canvas.drawBitmap(bmp, 0, 0, null);
             canvas.drawBitmap(player, x, y, null);
             if(k!=0)
             {
                 if(sp<=in+3) {


                     can.drawBitmap(loading1, can.getWidth() / 2 , 50, null);
                 }
                 else if(sp<in+6)
                 {
                     can.drawBitmap(loading2, can.getWidth() / 2 , 50, null);
                 }
                 else
                 {
                     can.drawBitmap(loading3, can.getWidth() / 2 , 50, null);
                 }

                 isInvincible = true;

             }
             else
             {
                 isInvincible=false;
             }
         }
        paint.setColor(Color.WHITE);
        paint.setTextSize(80);
        str= String.valueOf(sc);
        sc++;
        canvas.drawText(str,10,120,paint);
        for (i = 0; i < sprites.size(); i++) {
            sprites.get(i).onDraw(canvas);


            Log.d("Sprite : ", "i=" + sprites.indexOf(sprites.get(i)));

        }
        for (i = 0; i < needles.size(); i++) {
            needles.get(i).onDraw(canvas);

            Log.d("Sprite : ", "i=" + needles.indexOf(needles.get(i)));
        }
     }

    public void update() {
        if (x + player.getWidth() >= can.getWidth()) {
            x = can.getWidth() - player.getWidth();
        }

        for (i = 0; i < sprites.size(); i++) {
            spr = sprites.get(i);

            if (spr.isColliding(x, y, player)) {
                j = spr.jis();
                ySpeed = -5 - j;
                break;
            }
            else {
                ySpeed = 10;
            }


        }

        sc = sc + j / 10;


            for (i = 0; i < needles.size(); i++) {
                spr = needles.get(i);
                if (spr.isColliding(x, y, player)) {
if(!isInvincible) {
    end();
    break;
}
                }

            }
            if(y <= 7)
            {
                if(!isInvincible)
                {
                    y=7;
                    end();
                }
            }
            if (y > getHeight()  ) {

                end();
            }
        y=y+ySpeed;
    }


   public  void timer() {

k=1;




    }
    public void end()
    {

                nSound.start();
                Bitmap pop = BitmapFactory.decodeResource(getResources(), R.drawable.pop);

                can.drawBitmap(pop, x, y, null);
                flag = 1;

                sprites.clear();
                needles.clear();
                mCountDownTimer.cancel();




                Intent homeIntent = new Intent(getContext(), PlayAgain.class);
                homeIntent.putExtra("score",sc);
                getContext().startActivity(homeIntent);
                gameThread.setRunning(false);








    }
    public boolean onTouchEvent(MotionEvent event) {

        if(event.getAction() == MotionEvent.ACTION_MOVE)
        {
            x= (int)event.getX();


        }




        return true;
    }



    public boolean gameRun() {
        if(flag==0)
            return true;
        return false;
    }

    public GameThread gameth() {
        return gameThread;

    }
}
