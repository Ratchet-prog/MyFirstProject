package com.example.game;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;

import java.util.Random;



class Sprite {
    private  int x = 0,x1=0,pp=0;
    private  int y = 0,y1=0,gy=0;
    private int xSpeed = 15;
    private int ySpeed = 5;
    private GameView gameView;
    private Bitmap bmp1,bmp2,star1;
int j=1;
Boolean play= false;
    public Sprite(GameView gameView, Bitmap bmp,  int j1) {
        j=j1;
        this.gameView = gameView;
        this.bmp1 = bmp;

        Random rnd = new Random(System.currentTimeMillis());
        x=rnd.nextInt(550)+10;
        y = rnd.nextInt(100) + 1 + gameView.getHeight();

x1=x;





    }


public void sendStar(Bitmap st) {
    star1=st;

}
    private void update() {

        y = y - ySpeed-j;

    }
    void onDraw(Canvas canvas) {
    canvas.drawBitmap(bmp1, x, y, null);
    if(pp==1)
    {
        canvas.drawBitmap(star1,x,y-star1.getHeight(),null);
        isInvincible();

    }


    update();


    }

    boolean isColliding(int xb, int yb ,Bitmap ball) {
        if((xb +ball.getWidth()/2 >= x && xb <= (x+bmp1.getWidth()))  && (yb<=y && yb+ball.getHeight()>=y)
        )
        {

           return true;
        }
        return false;
    }

    public int jis() {
        return  j;
    }


    public int isTouching(int xb, int yb, Bitmap ball) {
       if(xb+ball.getWidth()>x && xb+ball.getWidth() < x+bmp1.getWidth()/2  && (yb+ball.getHeight()>=y && yb+ball.getHeight()<=y+bmp1.getHeight()))
           return x-ball.getWidth();
       else if(xb>x+bmp1.getWidth()/2 && xb < x+bmp1.getWidth() && yb+ball.getHeight()>=y && yb+ball.getHeight()<=y+bmp1.getHeight())
           return x+bmp1.getWidth();
        return 0;
    }


    public void sendp(int i) {
        pp=i;
    }

    public int isInvincible() {
        int xb=gameView.getx();
       int yb= gameView.gety();
        Bitmap player= gameView.bmp();
     if((xb>=x && xb<=x+star1.getWidth() || xb+player.getWidth()>=x && xb+player.getWidth()<=x+star1.getWidth())  && ((yb + player.getHeight()>=y-star1.getHeight() && yb+player.getHeight() <= y)|| (yb + player.getHeight()/2 >=y-star1.getHeight() && yb+player.getHeight()/2 <= y)))
     {
         pp=0;
         gameView.in=gameView.sp;
         gameView.timer();
     }
     return 1;
    }
}
