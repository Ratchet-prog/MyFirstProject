package com.example.game;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.media.AudioManager;
import android.os.Bundle;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import static java.lang.System.exit;

public class MainActivity extends AppCompatActivity {

    GameView gm;
    AlertDialog alertDialog;
RelativeLayout mPreview;
    private long backPressedTime;
    private Toast backToast;
    Button positiveDialog,btn;
    AlertDialog.Builder dialogBuilder;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        gm = new GameView(this);
        setContentView(R.layout.surface);
        mPreview = findViewById(R.id.surfaceView);
        mPreview.addView(gm);
        btn = findViewById(R.id.button2);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
              pause();
            }
        });



    }

    @Override
    public void onBackPressed() {
        moveTaskToBack(false);
        if (gm.gameRun()) {

pause();
        }
    }
    void pause()
    {
        gm.gameth().pause();

            gm.mCountDownTimer.cancel();

        dialogBuilder = new AlertDialog.Builder(MainActivity.this);
        View layoutView = getLayoutInflater().inflate(R.layout.pause, null);
        Button Resume = layoutView.findViewById(R.id.button3);

        Button Exit = layoutView.findViewById(R.id.button5);
        TextView dialogText=layoutView.findViewById(R.id.textView);
        dialogBuilder.setView(layoutView);
        alertDialog = dialogBuilder.create();
        alertDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        alertDialog.show();

        Resume.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gm.gameth().unpause();
                gm.mCountDownTimer.start();
                alertDialog.dismiss();
            }
        });

        Exit .setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (backPressedTime + 2000 > System.currentTimeMillis()) {
                    backToast.cancel();
                    System.exit(0);
                    return;
                } else {
                    backToast = Toast.makeText(getBaseContext(), "Press back again to exit", Toast.LENGTH_SHORT);
                    backToast.show();
                }
                backPressedTime = System.currentTimeMillis();


            }
        });
    }



}
