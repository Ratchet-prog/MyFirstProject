package com.example.game;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class PlayAgain extends AppCompatActivity {
    Button btn;
    private TextView DisplayScore;
    private String score;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_play_again);
        score = getIntent().getExtras().get("score").toString();
        DisplayScore = findViewById(R.id.textView);
        btn = findViewById(R.id.button);
        SharedPreferences myScore = getSharedPreferences("MyAwesomeScore", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = myScore.edit();
        editor.putInt("score", Integer.parseInt(score));
        editor.commit();
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent homeIntent = new Intent( PlayAgain.this , MainActivity.class);
                startActivity(homeIntent);

            }
        });
        DisplayScore.setText("score = " + score);
    }


}
